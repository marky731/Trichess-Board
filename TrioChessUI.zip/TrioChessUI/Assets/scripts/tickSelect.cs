using UnityEngine;

public class TickController : MonoBehaviour
{
    public GameObject tickImage;

    private bool isTickVisible = false;

    public void ToggleTick()
    {
        isTickVisible = !isTickVisible;
        tickImage.SetActive(isTickVisible);
    }
}
