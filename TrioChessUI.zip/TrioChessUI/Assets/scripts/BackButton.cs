using UnityEngine;
using UnityEngine.SceneManagement;

public class BackButton : MonoBehaviour
{
    public void GoBack()
    {
        if (SceneHistory.previousSceneIndex >= 0)
        {
            SceneManager.LoadScene(SceneHistory.previousSceneIndex);
        }
        else
        {
            SceneManager.LoadScene("mainMenuPage"); // Sahne adını Build Settings'teki isimle aynı yaz
        }
    }
}
