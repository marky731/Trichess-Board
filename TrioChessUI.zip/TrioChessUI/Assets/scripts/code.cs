using UnityEngine;
using UnityEngine.SceneManagement;

public class mainMenuPage : MonoBehaviour
{
    // Bu metot oyunu başlatmak için mevcut sahneden bir sonrakini yükler
    public void StartGame()
    {
        int nextIndex = SceneManager.GetActiveScene().buildIndex + 1;
        SceneManager.LoadScene(nextIndex);
    }

    // Rectangle1 butonuna tıklanınca loginPage sahnesini yükler
    public void OpenloginPage()
    {
        SceneManager.LoadScene("loginPage"); 
    }

    // Rectangle2 butonuna tıklanınca signUpPage sahnesini yükler
    public void OpensignUpPage()
    {
        SceneManager.LoadScene("signUpPage"); // Sahne ismi signUpPage olmalı
    }

    // Yeni: SettingsPage sahnesini açar
    public void OpensettingsPage()
    {
        SceneManager.LoadScene("settingsPage");
    }
      
    // HintPage sahnesini açar
    public void OpenhintPage()
    {
    SceneManager.LoadScene("hintPage"); // Sahne ismi HintPage olmalı
    }
}
