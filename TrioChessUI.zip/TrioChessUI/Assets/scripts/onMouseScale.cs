using UnityEngine;

public class onMouseScale : MonoBehaviour
{
    private Vector3 originalScale;
    public float scaleFactor = 1.3f; // Ne kadar büyüsün?

    void Start()
    {
        originalScale = transform.localScale; // Başlangıç ölçeğini kaydet
    }

    public void PointerEnter()
    {
        transform.localScale = originalScale * scaleFactor; // Büyüt
    }

    public void PointerExit()
    {
        transform.localScale = originalScale; // Eski haline dön
    }
}

