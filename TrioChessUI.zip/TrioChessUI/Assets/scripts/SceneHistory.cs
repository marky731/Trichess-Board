using UnityEngine;

public static class SceneHistory
{
    public static int previousSceneIndex = -1;
}
